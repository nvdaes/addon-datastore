# -*- coding: UTF-8 -*-
# skipTranslation: Module to get translated texts from NVDA
# Based on implementation made by Alberto Buffolino
# https://github.com/nvaccess/nvda/issues/4652
# Copyright (C) 2016 Noelia Ruiz Martínez
# Released under GPL 2


def translate(text):
	return _(text)
